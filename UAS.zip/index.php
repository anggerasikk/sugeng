<?php
header("Location: beranda/index.php");
exit;
?>