<?php
// Redirect to profile.php as the main dashboard
header("Location: profile.php");
exit;
?>
