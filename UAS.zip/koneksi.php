<?php
$host = "localhost";
$username = "root";
$password = "";
$database = "sugeng";
$koneksi = mysqli_connect($host, $username, $password, $database);
?>  